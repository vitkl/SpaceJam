/**
 * Created by kono on 2014/01/24.
 */
/*
'use strict';

angular.module('cyViewerApp')
    .factory('VisualStyles', ['$resource', function ($resource) {
        return $resource('data/:filename', {filename: '@filename'});
    }]
);*/