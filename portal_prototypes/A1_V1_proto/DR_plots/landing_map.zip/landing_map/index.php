

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">  
 <style>
#gallery {
  scroll-snap-type: x mandatory;
  overflow-x: scroll;
    overflow-y: scroll;
  display: flex;
    width: 1000px;
  height: 1000px;
}

#gallery img {
   scroll-snap-align: center;
}
</style>

<div id="gallery">
  <img src="./placeholder_violin.png">
  <img src="./place_holder_box.png">
</div>
    
</head>
</html>